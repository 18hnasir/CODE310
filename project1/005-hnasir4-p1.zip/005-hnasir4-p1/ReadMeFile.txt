Hammadullah Nasir	
hnasir4
G01112406
Lecture: 005
